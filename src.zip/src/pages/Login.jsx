export default function Login() {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
      <h1 className="text-5xl font-bold">Login</h1>
    </div>
  );
}