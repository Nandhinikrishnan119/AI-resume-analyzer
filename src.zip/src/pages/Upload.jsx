export default function Upload() {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
      <h1 className="text-5xl font-bold">Upload Resume</h1>
    </div>
  );
}