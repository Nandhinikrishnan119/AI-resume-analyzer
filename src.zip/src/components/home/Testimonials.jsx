const testimonials = [
  {
    name: "Rahul Sharma",
    role: "Software Engineer",
    review:
      "My ATS score increased from 61% to 92%. I got interview calls within two weeks.",
  },
  {
    name: "Priya Nair",
    role: "Frontend Developer",
    review:
      "The AI suggestions helped me improve my resume dramatically.",
  },
  {
    name: "David Lee",
    role: "Data Analyst",
    review:
      "The dashboard made it easy to identify missing skills and keywords.",
  },
];

export default function Testimonials() {
  return (
    <section className="bg-slate-950 py-24">

      <div className="max-w-7xl mx-auto px-6">

        <h2 className="text-5xl font-bold text-center mb-16">
          Loved by Students
        </h2>

        <div className="grid md:grid-cols-3 gap-8">

          {testimonials.map((item, index) => (
            <div
              key={index}
              className="glass rounded-3xl p-8"
            >
              <p className="text-gray-300">
                "{item.review}"
              </p>

              <h3 className="mt-8 text-xl font-bold">
                {item.name}
              </h3>

              <p className="text-blue-400">
                {item.role}
              </p>
            </div>
          ))}

        </div>

      </div>

    </section>
  );
}