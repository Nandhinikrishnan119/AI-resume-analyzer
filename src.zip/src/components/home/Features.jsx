import {
  FaRobot,
  FaChartLine,
  FaFileAlt,
  FaBrain,
  FaSearch,
  FaCheckCircle,
} from "react-icons/fa";

const features = [
  {
    icon: <FaRobot size={35} />,
    title: "AI Resume Review",
    desc: "Get instant AI-powered suggestions.",
  },
  {
    icon: <FaChartLine size={35} />,
    title: "ATS Score",
    desc: "Know how recruiters see your resume.",
  },
  {
    icon: <FaFileAlt size={35} />,
    title: "Resume Parsing",
    desc: "Automatic resume analysis.",
  },
  {
    icon: <FaBrain size={35} />,
    title: "AI Insights",
    desc: "Improve your chances of selection.",
  },
  {
    icon: <FaSearch size={35} />,
    title: "Keyword Match",
    desc: "Optimize for job descriptions.",
  },
  {
    icon: <FaCheckCircle size={35} />,
    title: "Interview Ready",
    desc: "Professional improvement tips.",
  },
];

export default function Features() {
  return (
    <section className="bg-slate-950 py-24">

      <div className="max-w-7xl mx-auto px-6">

        <h2 className="text-5xl font-bold text-center text-white">
          Everything you need
        </h2>

        <p className="text-center text-gray-400 mt-5 mb-16">
          AI-powered resume optimization platform.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

          {features.map((feature, index) => (
            <div
              key={index}
              className="glass rounded-3xl p-8 hover:scale-105 transition"
            >
              <div className="text-blue-400">
                {feature.icon}
              </div>

              <h3 className="text-2xl font-bold mt-6">
                {feature.title}
              </h3>

              <p className="text-gray-300 mt-4">
                {feature.desc}
              </p>

            </div>
          ))}

        </div>

      </div>

    </section>
  );
}