const stats = [
  {
    number: "50K+",
    title: "Resumes Analyzed",
  },
  {
    number: "95%",
    title: "ATS Accuracy",
  },
  {
    number: "10K+",
    title: "Users",
  },
  {
    number: "24/7",
    title: "AI Support",
  },
];

export default function Stats() {
  return (
    <section className="bg-slate-950 py-24">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-8 px-6">

        {stats.map((item, index) => (
          <div
            key={index}
            className="glass rounded-3xl p-8 text-center"
          >
            <h2 className="text-5xl font-bold text-blue-400">
              {item.number}
            </h2>

            <p className="mt-4 text-gray-300">
              {item.title}
            </p>
          </div>
        ))}

      </div>
    </section>
  );
}