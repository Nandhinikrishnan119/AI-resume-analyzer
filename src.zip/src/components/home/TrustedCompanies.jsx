import { FaGoogle, FaMicrosoft, FaAmazon } from "react-icons/fa";
import { SiNetflix, SiAdobe, SiMeta } from "react-icons/si";

const companies = [
  { name: "Google", icon: <FaGoogle /> },
  { name: "Microsoft", icon: <FaMicrosoft /> },
  { name: "Amazon", icon: <FaAmazon /> },
  { name: "Meta", icon: <SiMeta /> },
  { name: "Netflix", icon: <SiNetflix /> },
  { name: "Adobe", icon: <SiAdobe /> },
];

export default function TrustedCompanies() {
  return (
    <section className="bg-slate-950 py-32">
      <div className="max-w-6xl mx-auto px-6">
        <p className="text-center uppercase tracking-[6px] text-gray-500 mb-16">
          Trusted by candidates applying to
        </p>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 place-items-center">
          {companies.map((company) => (
            <div
              key={company.name}
              className="glass w-40 h-36 rounded-3xl flex flex-col items-center justify-center"
            >
              <div className="text-5xl text-blue-400 mb-4">
                {company.icon}
              </div>

              <p className="text-white font-semibold">
                {company.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}