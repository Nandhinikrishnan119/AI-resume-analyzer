import { Link } from "react-router-dom";

export default function CTA() {
  return (
    <section className="bg-gradient-to-r from-blue-700 to-purple-700 py-24">
      <div className="max-w-5xl mx-auto px-6 text-center">

        <h2 className="text-5xl font-bold text-white">
          Ready to improve your resume?
        </h2>

        <p className="text-blue-100 mt-6 text-lg">
          Upload your resume and get an AI-powered ATS analysis in seconds.
        </p>

        <Link
          to="/upload"
          className="inline-block mt-10 px-10 py-4 rounded-xl bg-white text-blue-700 font-bold hover:scale-105 transition"
        >
          Get Started
        </Link>

      </div>
    </section>
  );
}