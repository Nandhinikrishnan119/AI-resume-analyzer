import { FaGithub, FaLinkedin, FaTwitter } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-white/10 py-12">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">

        <div>
          <h2 className="text-2xl font-bold text-white">
            Resume<span className="text-blue-400">AI</span>
          </h2>

          <p className="text-gray-400 mt-2">
            AI-powered Resume Analyzer
          </p>
        </div>

        <div className="flex gap-6 text-2xl text-gray-300">
          <FaGithub className="hover:text-white cursor-pointer" />
          <FaLinkedin className="hover:text-blue-400 cursor-pointer" />
          <FaTwitter className="hover:text-sky-400 cursor-pointer" />
        </div>

        <p className="text-gray-500 text-sm">
          © 2026 ResumeAI. All rights reserved.
        </p>

      </div>
    </footer>
  );
}