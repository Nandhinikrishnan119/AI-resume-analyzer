import { Link } from "react-router-dom";
import { FaRobot } from "react-icons/fa";
import { motion } from "framer-motion";

export default function Navbar(){

return(

<nav className="fixed top-0 left-0 w-full z-50 glass">

<div className="max-w-7xl mx-auto flex justify-between items-center px-8 py-5">

<Link
to="/"
className="flex items-center gap-3 text-2xl font-bold">

<FaRobot className="text-blue-400"/>

<span className="gradient-text">
ResumeAI
</span>

</Link>

<div className="hidden md:flex gap-10">

<Link to="/">Home</Link>

<Link to="/about">About</Link>

<Link to="/upload">Upload</Link>

<Link to="/dashboard">Dashboard</Link>

</div>

<motion.div
whileHover={{scale:1.1}}
whileTap={{scale:.9}}
>

<Link
to="/login"
className="primary-btn">

Login

</Link>

</motion.div>

</div>

</nav>

)

}